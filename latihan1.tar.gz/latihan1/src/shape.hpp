
// Base class
class Shape  {
   public:
      void setWidth(int w) {
         width = w;
      }

      void setHeight(int h) {
         height = h;
      }

   protected:
      int width;
      int height;
};

// Derived class
class rectangle: public Shape {
   public:
      int getArea() {
         return (width * height);
      }
};
